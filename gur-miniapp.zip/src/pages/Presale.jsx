export default function Presale() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-2">Presale</h1>
      <div className="bg-white p-4 rounded-xl shadow-md mb-4">
        <p>Rate: 1 TON = 2,000 $GUR</p>
        <p>Send TON to: UQCq0ckaUPa1TSrfo2ET7r_HrqAxMSM6ddGi75fm3aARGHK3</p>
        <p>Progress: 5%</p>
      </div>
    </div>
  );
}